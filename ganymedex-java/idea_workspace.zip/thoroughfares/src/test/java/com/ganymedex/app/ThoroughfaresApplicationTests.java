package com.ganymedex.app;

import com.ganymedex.app.Sender.OneToMany;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.UUID;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ThoroughfaresApplicationTests {


	@Test
	public void contextLoads() {
	}

	@Autowired
	private OneToMany oneToMany;


	@Test
	public void OneToMany() {
		/*for (int i = 0; i < 20; i++) {
			oneToMany.send("支付金额"+i);
		}*/
		while (true){
			oneToMany.send("支付金额"+ UUID.randomUUID().toString());
		}
	}

	@Test
	public void manyToMany() {
		for (int i = 0; i < 20; i++) {
			//messageSender1.send(String.format("hi(%d)", i + 1));

			//messageSender2.send(String.format("hi(%d)", i + 1));
		}
	}


}
