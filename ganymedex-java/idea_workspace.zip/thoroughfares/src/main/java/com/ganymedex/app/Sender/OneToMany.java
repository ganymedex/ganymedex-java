package com.ganymedex.app.Sender;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class OneToMany {

        @Autowired
        private AmqpTemplate rabbitTemplate;

        public void send(String msg) {
            String sendMsg = msg + new Date();
            System.out.println("Sender1 : " + sendMsg);
            this.rabbitTemplate.convertAndSend("hello", sendMsg);
        }

}
